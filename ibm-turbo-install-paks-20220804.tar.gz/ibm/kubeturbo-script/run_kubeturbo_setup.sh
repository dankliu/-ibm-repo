#!/bin/sh

echo "--------------------------------------Run KubeTurbo Install Pak v8.5.7"
read -p "Continue KubeTurbo Install? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit

echo "------create namespace kubeturbo"
kubectl create namespace kubeturbo

echo "------create service account"
kubectl create sa turbo-user -n kubeturbo
kubectl -n kubeturbo apply -f serviceAccount.yaml

echo "------create role binding"
kubectl -n kubeturbo apply -f serviceAccountRoleBinging.yaml


read -p "Must be modify kubeturbo configMap setting, need continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit
echo "------create configMap"
kubectl -n kubeturbo apply -f turboConfig.yaml

echo "------create deployment kubeturbo"
kubectl -n kubeturbo apply -f kubeTurboDeploy.yaml

echo "--------------------------------------Done KubeTurbo Install"


