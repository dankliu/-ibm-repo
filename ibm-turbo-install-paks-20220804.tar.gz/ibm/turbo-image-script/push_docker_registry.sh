#!/bin/sh

read -p "Enter Docker Registry, ex.localhost:5000 : " registry
read -p "Continue Load Image? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1

#manual-setting-registry
#registry=localhost:5000


echo "--------------------------------------Start Push Image Registry"


for name in `docker images | awk '{if(NR>1){ print $1 ":" $2}}'`
do
  echo "Backup Image: $name"
  IFS=: read -r repoName repoTag <<< $name

#  echo "REPOSITORY: $repoName"
#  echo "TAG: $repoTag"

  echo "Tag  Command: docker image tag $repoName:$repoTag $registry/$repoName:$repoTag"
  echo "Push Command: docker push $registry/$repoName:$repoTag"
  
  docker image tag $repoName:$repoTag $registry/$repoName:$repoTag
  docker push $registry/$repoName:$repoTag
done

  echo "--------------------------------------Done All Docker Image Backup"
  echo "Check Registry: curl -X GET http://$registry/v2/_catalog"
  curl -X GET http://$registry/v2/_catalog


