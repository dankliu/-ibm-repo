#!/bin/sh

echo "--------------------------------------Run Trubo Delete"
read -p "Continue Turbo Delete? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit

kubectl delete -f turbo_default_cr.yaml -n turbonomic
kubectl delete -f operator.yaml -n turbonomic

echo "--------------------------------------Done Trubo Delete"


