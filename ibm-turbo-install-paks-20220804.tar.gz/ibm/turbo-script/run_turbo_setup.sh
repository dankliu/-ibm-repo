#!/bin/sh

echo "--------------------------------------Run Turbo Install Pak v8.5.7"
read -p "Continue Turbo Install? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit

echo "------create namespace turbonomic"
kubectl create namespace turbonomic

echo "------create the Custom Resource, must check kubernetes version 1.22 and higher"
echo "------kubernetes version:"
kubectl version

read -p "If kubernetes version lower than 1.22, need continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit
kubectl create -f charts.helm.k8s.io_xls.yaml

echo "------operator service account"
kubectl create -f service_account.yaml -n turbonomic

echo "------create the role"
kubectl create -f role.yaml -n turbonomic

echo "------create the role binding"
kubectl create -f role_binding.yaml -n turbonomic

echo "------init operator pod"
kubectl create -f operator.yaml -n turbonomic

echo "------check operator status"
kubectl get pods -n turbonomic

sleep 60

echo "------create custom Resource"

read -p "Must be modify default custom resource turbo_default_cr.yaml, need continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit

kubectl apply -f turbo_default_cr.yaml -n turbonomic

echo "--------------------------------------Done Trubo Install"

echo "waiting for turbo pod start, now can exit process"
kubectl get pods -n turbonomic -w


