#!/bin/sh
imagePath=/ibm/turbo-backup-image/2022-07-24-1913-24/


echo "--------------------------------------Start Load Image Files on $imagePath"

for file in "${imagePath}/"/*
do
    imageName=${file##*/}

    echo "Load Image: $imageName"
    echo "Load Command: docker load -i $imageName"
    docker load -i $imagePath$imageName
done


echo "--------------------------------------Done Load Image Files"


