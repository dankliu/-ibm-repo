#!/bin/sh

  echo "--------------------------------------Start All Docker Image Backup"

time=$(date "+%Y-%m-%d-%H%M-%S")
targetDir=/ibm/turbo-backup-image/$time/
mkdir $targetDir -p
zipFormat=.tar
replace=/


for name in `docker images | awk '{if(NR>1){ print $1 ":" $2}}'` 
do
  echo "Backup Image: $name"  
  IFS=: read -r repoName repoTag <<< $name
  
#  echo "REPOSITORY: $repoName"
#  echo "TAG: $repoTag"
  
  replaceRepoName=${repoName/$replace/"-"}
  echo "Backup Command: docker save $repoName > $targetDir$replaceRepoName-$repoTag$zipFormat"

  docker save $repoName > $targetDir$replaceRepoName-$repoTag$zipFormat
 

done
  echo "--------------------------------------Done All Docker Image Backup"


